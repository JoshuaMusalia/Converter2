package com.bethuel.converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.convertButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText =  findViewById(R.id.metresValue);
                String inputMetres = editText.getText().toString();
                float metres = Float.parseFloat(inputMetres);
                float centimetres = (float) (metres * 100.0000);

                TextView centimetresTextView = findViewById(R.id.convertedTocentimetres);
                centimetresTextView.setText(String.format("%s cm", centimetres));
            }
        });

        Button exitButton = findViewById(R.id.exitButton);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}